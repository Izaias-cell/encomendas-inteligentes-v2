{
  "name": "Encomendas Inteligentes",
  "short_name": "Encomendas",
  "description": "Sistema de gestão de encomendas",
  "start_url": "/",
  "scope": "/",
  "display": "standalone",
  "display_override": ["standalone", "window-controls-overlay"],
  "orientation": "portrait",
  "background_color": "#ffffff",
  "theme_color": "#16a34a",
  "icons": [
    {
      "src": "/icon-192.png",
      "sizes": "192x192",
      "type": "image/png"
    },
    {
      "src": "/icon-512.png",
      "sizes": "512x512",
      "type": "image/png"
    }
  ]
}