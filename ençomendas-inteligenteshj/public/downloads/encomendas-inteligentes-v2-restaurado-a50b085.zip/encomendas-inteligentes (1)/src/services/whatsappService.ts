import { Morador } from '../types';
import { supabase } from '../lib/supabase';

export interface WhatsAppVariables {
  saudacao: string;
  nome_morador: string;
  unidade: string;
  rua_logradouro?: string;
  bloco_torre?: string;
  codigo_retirada: string;
  data_recebimento: string;
  hora_recebimento: string;
  nome_condominio: string;
  observacao?: string;
  pickup_token?: string;
  quantidade_encomendas?: number;
  tipo_notificacao?: 'disponivel' | 'retirada';
  retirado_por?: string;
  hora_retirada?: string;
  photo_url?: string;
  is_large_package?: boolean;
}

/**
 * Generates a 4-digit random pickup code
 */
export const generatePickupCode = (): string => {
  return Math.floor(1000 + Math.random() * 9000).toString();
};

/**
 * Returns a greeting based on the current time
 */
export const getGreeting = (): string => {
  const hour = new Date().getHours();
  // 06:00 até 11:59 → Bom dia
  if (hour >= 6 && hour < 12) return 'Bom dia';
  // 12:00 até 17:59 → Boa tarde
  if (hour >= 12 && hour < 18) return 'Boa tarde';
  // 18:00 até 05:59 → Boa noite
  return 'Boa noite';
};

/**
 * Formats the unit type and number correctly
 */
export const formatUnit = (resident: Morador): string => {
  const type = resident.unit_type || 'Unidade';
  return `${type} ${resident.unidade}`;
};

/**
 * Assembles the WhatsApp message from variables following the "Encomendas Inteligentes" standard
 */
export const assembleWhatsAppMessage = (vars: WhatsAppVariables): string => {
  const isRetirada = vars.tipo_notificacao === 'retirada';
  const qty = vars.quantidade_encomendas || 1;
  const isPlural = qty > 1;
  
  if (isRetirada) {
    const quantityText = `*(${qty} ${isPlural ? 'encomendas' : 'encomenda'})*`;
    const statusLine = `📦 Sua${isPlural ? 's' : ''} encomenda${isPlural ? 's' : ''} ${isPlural ? 'foram' : 'foi'} retirada${isPlural ? 's' : ''} ${quantityText}`;

    return [
      `${vars.saudacao}, ${vars.nome_morador}!`,
      '',
      statusLine,
      '',
      `📍 ${vars.unidade}`,
      `🕒 ${vars.hora_retirada || vars.hora_recebimento}`,
      `👤 Retirado por: *${vars.retirado_por || 'morador'}*`,
      '',
      `Qualquer dúvida estamos à disposição.`,
      `*${vars.nome_condominio}*`
    ].join('\n');
  }

  // Modelo especial para ENCOMENDA GRANDE
  if (vars.is_large_package) {
    return [
      `🔔 *AVISO IMPORTANTE – PORTARIA*`,
      '',
      `${vars.saudacao}, ${vars.nome_morador}.`,
      '',
      `Recebemos uma *ENCOMENDA GRANDE* para sua unidade (${vars.unidade}).`,
      '',
      `👉 Por gentileza, solicitamos retirada o mais breve possível devido ao volume.`,
      '',
      `📦 Ver encomenda:`,
      `${vars.photo_url || 'Foto não disponível'}`,
      '',
      `🔐 Código de retirada: ${vars.codigo_retirada}`,
      '',
      `Obrigado!`,
      `Portaria`
    ].join('\n');
  }

  // Modelo padronizado solicitado pelo usuário para encomendas recebidas
  const lines = [
    `${vars.saudacao}, ${vars.nome_morador}!`,
    '',
    `📦 Sua encomenda chegou!`,
    '',
    `📍 ${vars.unidade}`,
    `📦 Código: *${vars.codigo_retirada}*`,
    `🕒 ${vars.data_recebimento} às ${vars.hora_recebimento}`,
    '',
    `Por gentileza, apresente o código para retirada.`,
  ];

  if (vars.photo_url) {
    lines.push('');
    lines.push(`📸 Foto: CLIQUE PARA VER SUA ENCOMENDA 👇`);
    lines.push(vars.photo_url);
  }

  return lines.join('\n');
};

/**
 * Prepares the full WhatsApp message for a resident
 */
export const prepareWhatsAppNotification = (
  resident: Morador,
  condoName: string,
  pickupCode: string,
  observation?: string,
  pickupToken?: string,
  packageCount?: number,
  notificationType: 'disponivel' | 'retirada' = 'disponivel',
  retiradoPor?: string,
  horaRetirada?: string,
  photoUrl?: string,
  isLargePackage?: boolean
): string | null => {
  // Do not notify inactive residents
  if (!resident.ativo) return null;

  const now = new Date();
  
  // Rule for block/tower: use only if exists, don't duplicate
  const blocoTorre = resident.block || resident.bloco || resident.lote;

  const vars: WhatsAppVariables = {
    saudacao: getGreeting(),
    nome_morador: resident.nome,
    unidade: formatUnit(resident),
    bloco_torre: blocoTorre,
    codigo_retirada: pickupCode,
    data_recebimento: now.toLocaleDateString('pt-BR'),
    hora_recebimento: now.toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit' }),
    nome_condominio: condoName,
    observacao: observation,
    pickup_token: pickupToken,
    quantidade_encomendas: packageCount,
    tipo_notificacao: notificationType,
    retirado_por: retiradoPor,
    hora_retirada: horaRetirada,
    photo_url: photoUrl,
    is_large_package: isLargePackage
  };

  return assembleWhatsAppMessage(vars);
};

/**
 * Generates a WhatsApp wa.me link for manual sending
 */
export const getWhatsAppLink = (phone: string, message: string, photoUrl?: string): string => {
  let normalizedPhone = phone.replace(/\D/g, '');
  if (normalizedPhone.length > 0 && !normalizedPhone.startsWith('55')) {
    normalizedPhone = '55' + normalizedPhone;
  }
  
  // A mensagem já inclui o link da foto se disponível (conforme assembleWhatsAppMessage)
  const encodedMessage = encodeURIComponent(message);
  
  return `https://wa.me/${normalizedPhone}?text=${encodedMessage}`;
};

/**
 * Sends a WhatsApp message via dynamic API configuration
 */
export async function sendWhatsAppMessage(
  phone: string, 
  message: string, 
  condominiumId: string,
  config?: {
    api_url?: string;
    api_token?: string;
    instance_id?: string;
    whatsapp_provider?: string;
    photo_url?: string;
  }
) {
  if (!message || message.trim() === "") {
    console.warn('[WhatsApp Service] Mensagem vazia');
    return { error: 'Mensagem vazia', httpStatus: 400 };
  }

  // Normalize phone number: remove all non-digits
  let normalizedPhone = phone.replace(/\D/g, '');
  
  // Ensure it starts with 55
  if (normalizedPhone.length > 0 && !normalizedPhone.startsWith('55')) {
    normalizedPhone = '55' + normalizedPhone;
  }

  if (normalizedPhone.length < 12) { // 55 + DDD + 8 or 9 digits
    console.warn('[WhatsApp Service] Telefone inválido:', normalizedPhone);
    return { error: 'Telefone inválido', httpStatus: 400 };
  }

  console.log("Enviando mensagem para:", normalizedPhone);

  // Use provided config or fallback to hardcoded
  let baseApiUrl = (config?.api_url || "https://api.z-api.io").replace(/\/$/, '');
  const apiToken = (config?.api_token || "F3cec1a5aa2b14f0cbc667b86c75de2ebS").trim();
  const instanceId = (config?.instance_id || "3F0CA22AFB9F62F46D76D268A7BECB03").trim();

  const hasImage = !!config?.photo_url;
  let finalApiUrl = "";
  
  if (baseApiUrl.includes('/instances/')) {
    finalApiUrl = baseApiUrl;
  } else {
    const endpoint = hasImage ? 'send-image' : 'send-text';
    finalApiUrl = `${baseApiUrl}/instances/${instanceId}/token/${apiToken}/${endpoint}`;
  }

  try {
    const body = hasImage 
      ? {
          phone: normalizedPhone,
          image: config.photo_url,
          caption: message.trim()
        }
      : {
          phone: normalizedPhone,
          message: message.trim()
        };

    const response = await fetch(finalApiUrl, {
      method: "POST",
      headers: {
        "Content-Type": "application/json"
      },
      body: JSON.stringify(body)
    });

    const data = await response.json();
    const status_envio = response.ok ? 'sucesso' : 'erro';
    
    // Log no banco de dados
    try {
      await supabase.from('message_logs').insert([{
        condominium_id: condominiumId,
        telefone: normalizedPhone,
        status_envio: status_envio,
        status: response.ok ? 'sent' : 'failed',
        erro_api: !response.ok ? JSON.stringify(data) : null,
        data_envio: new Date().toISOString()
      }]);
    } catch (logErr) {
      console.error("Erro ao registrar log de mensagem:", logErr);
    }
    
    return { ...data, httpStatus: response.status, status_envio };
  } catch (error) {
    console.error("Erro na API de WhatsApp:", error);
    return { error: error instanceof Error ? error.message : String(error), httpStatus: 500, status_envio: 'erro' };
  }
}

/**
 * Tests the Z-API connection by attempting a simple profile fetch or similar lightweight call
 */
export async function testZApiConnection(apiUrl: string, apiToken: string) {
  if (!apiUrl || !apiToken) {
    return { success: false, error: 'URL ou Token não informados' };
  }

  try {
    // Z-API usually has a /status or /instance-status endpoint. 
    // We'll try to reach the base instance URL to check connectivity.
    // The apiUrl usually ends in /send-text, we need the base instance URL.
    const baseUrl = apiUrl.split('/token/')[0];
    
    const response = await fetch(baseUrl, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
        "Client-Token": apiToken
      }
    });

    if (response.ok) {
      return { success: true };
    } else {
      const data = await response.json().catch(() => ({}));
      return { success: false, error: data.message || `Erro HTTP ${response.status}` };
    }
  } catch (error) {
    return { success: false, error: error instanceof Error ? error.message : String(error) };
  }
}
